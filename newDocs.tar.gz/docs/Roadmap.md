# Roadmap

- [x] Buildings
- [x] Upgrades
  - [x] Fortune Upgrades
  - [x] Heavenly Upgrades
- [ ] Achievements
- [ ] Buffs
- [ ] Garden Hooks
- [ ] Grimoire Hooks <!-- Maybe? -->
- [ ] Temple Hooks <!-- Maybe? -->
- [ ] Lumps
  <!-- More? -->
