# Examples

## [Think Tank Building](https://github.com/Cppkies-Team/examples/tree/master/ThinkTank)

This addon provides an example on how to create a new building new upgrades and new achievements<!--Also could use this as a minigame creation example-->. Sprites by "Bt Y#0895".

<!--
### [LumpExample](https://github.com/Cppkies-Team/examples/tree/master/LumpExample)

This addon provides an example of creating a new lump type.

### [BuffExample](https://github.com/Cppkies-Team/examples/tree/master/BuffExample)

This addon provides an example of creating a new buff type, and adding a buff type to golden cookies.

### [MinigameExample](https://github.com/Cppkies-Team/examples/tree/master/MinigameExample)

This addon provides an example of creating a new plant, a new soil, a new spell, and a new pantheon spirit.
-->
