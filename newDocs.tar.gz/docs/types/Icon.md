# Icon

Icons are small pieces of art, they are 48 by 48, and can provide a source.

## Type

`[number, number, string?]`

1. `number` - The X coordinate of the icon
2. `number` - The Y coordinate of the icon
3. `string` - The optional source of the iconsheet, falls back to `buildingLink`, then to the default iconsheet
